/**
 * 德创新能源
 *
 * https://www.desan.com
 *
 * 版权所有，侵权必究！
 */

package com.xjj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminApplication {
	public static void main(String[] args) {
		SpringApplication.run(AdminApplication.class, args);
	}
}