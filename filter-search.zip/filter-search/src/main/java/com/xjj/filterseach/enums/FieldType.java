package com.xjj.filterseach.enums;

/**
 * 字段类型
 *
 * @author xjj
 */

public enum FieldType {
    /**
     * 字符串类型
     */
    STRING_FIELD(new OperatorType[]{
            OperatorType.EQUAL,
            OperatorType.LIKE
    }),
    /**
     * 数字类型
     */
    NUMERIC_FIELD(new OperatorType[]{
            OperatorType.EQUAL,
            OperatorType.GREATER_THAN,
            OperatorType.LESS_THAN
    }),
    /**
     * 时间类型
     */
    TIME_FIELD(new OperatorType[]{
            OperatorType.EQUAL,
            OperatorType.GREATER_THAN,
            OperatorType.LESS_THAN,
            OperatorType.BETWEEN
    }),
    /**
     * 枚举类型
     */
    ENUM_FIELD(new OperatorType[]{
            OperatorType.EQUAL,
            OperatorType.NOT_EQUAL
    });

    private final OperatorType[] operatorType;

    FieldType(OperatorType[] operatorType) {
        this.operatorType = operatorType;
    }

    public OperatorType[] getOperatorType() {
        return operatorType;
    }
}
