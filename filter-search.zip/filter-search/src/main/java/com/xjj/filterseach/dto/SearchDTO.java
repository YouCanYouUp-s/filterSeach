package com.xjj.filterseach.dto;

import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * 查询DTO
 * @author xjj
 */
@Data
public class SearchDTO {
    /**
     * 过滤字段
     */
    List<FilterDTO> list;
    /**
     * 分页参数 page limit
     */
    Map<String, Object> params;
}
