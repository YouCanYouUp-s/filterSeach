package com.xjj.filterseach.dto;

import com.xjj.filterseach.enums.OperatorType;
import lombok.Data;

/**
 * 操作符
 * @author xjj
 */
@Data
public class Operator {
    /**
     * 操作类型
     */
    private OperatorType type;
    /**
     * 输入框的个数
     */
    private int value;
    /**
     * 标签
     */
    private String label;

    public Operator(OperatorType type, int value, String label) {
        this.type = type;
        this.value = value;
        this.label = label;
    }
}
