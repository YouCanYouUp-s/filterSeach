package com.xjj.filterseach.annotation;


import com.xjj.filterseach.enums.OperatorType;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 操作类型拼接方法绑定注解
 * @author xjj
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface OperatorMethod {
    OperatorType type();
}
