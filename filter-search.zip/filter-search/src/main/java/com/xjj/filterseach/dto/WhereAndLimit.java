package com.xjj.filterseach.dto;

import lombok.Data;

/**
 * 根据searchDTO解析where 和 limit sql
 * @author xjj
 */
@Data
public class WhereAndLimit {
    private String whereSql;

    private String limitSql;
}
