package com.xjj.filterseach.annotation;


import com.xjj.filterseach.enums.FieldType;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author xjj
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface FilterQueryField {
    /**
     * 字段名
     */
    String fieldName();
    /**
     * 字段标签
     */
    String label();
    /**
     * 字段类型
     */
    FieldType type();
}
