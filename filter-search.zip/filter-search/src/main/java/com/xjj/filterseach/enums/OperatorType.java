package com.xjj.filterseach.enums;

import com.xjj.filterseach.annotation.OperatorMethod;
import com.xjj.filterseach.dto.FilterDTO;
import lombok.Getter;
import lombok.ToString;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * 操作符类型
 *
 * @author xjj
 */
@ToString
@Getter
public enum OperatorType {
    /**
     * 等于
     */
    EQUAL(1, "等于"),
    /**
     * 不等于
     */
    NOT_EQUAL(1,"不等于"),
    /**
     * 大于
     */
    GREATER_THAN(1, "大于"),
    /**
     * 小于
     */
    LESS_THAN(1, "小于"),
    /**
     * 介于
     */
    BETWEEN(2, "介于"),
    /**
     * 包含
     */
    LIKE(1, "包含");

    /**
     * 参数个数
     */
    private final int value;

    /**
     * 标签
     */
    private final String label;

    private final static Map<OperatorType, Method> CACHE = new HashMap<>();

    static {
        for (Method method : OperatorType.class.getDeclaredMethods()) {
            if (method.isAnnotationPresent(OperatorMethod.class)) {
                CACHE.put(method.getAnnotation(OperatorMethod.class).type(), method);
            }
        }
    }

    public static Method getMethodByOperatorType(OperatorType operatorType){
        return CACHE.get(operatorType);
    }

    OperatorType(int value, String label) {
        this.value = value;
        this.label = label;
    }

    @OperatorMethod(type = EQUAL)
    public StringBuilder equal(FilterDTO filter, StringBuilder builder) {
        builder.append(filter.getFieldName())
                .append(" = ")
                .append("'").append(filter.getValue()[0]).append("'");
        return builder;
    }

    @OperatorMethod(type = NOT_EQUAL)
    public StringBuilder notEqual(FilterDTO filter, StringBuilder builder) {
        builder.append(filter.getFieldName())
                .append(" != ")
                .append("'").append(filter.getValue()[0]).append("'");
        return builder;
    }

    @OperatorMethod(type = GREATER_THAN)
    public StringBuilder greaterThan(FilterDTO filter, StringBuilder builder) {
        builder.append(filter.getFieldName())
                .append(" > ")
                .append("'").append(filter.getValue()[0]).append("'");
        return builder;
    }

    @OperatorMethod(type = LESS_THAN)
    public StringBuilder lessThan(FilterDTO filter, StringBuilder builder) {
        builder.append(filter.getFieldName())
                .append(" < ")
                .append("'").append(filter.getValue()[0]).append("'");
        return builder;
    }

    @OperatorMethod(type = BETWEEN)
    public StringBuilder between(FilterDTO filter, StringBuilder builder) {
        builder.append(filter.getFieldName())
                .append(" between ").append("'").append(filter.getValue()[0]).append("'")
                .append(" and ").append("'").append(filter.getValue()[1]).append("'");
        return builder;
    }

    @OperatorMethod(type = LIKE)
    public StringBuilder like(FilterDTO filter, StringBuilder builder) {
        builder.append(filter.getFieldName()).append(" like concat('%',")
                .append("'").append(filter.getValue()[0]).append("'")
                .append(",'%')");
        return builder;
    }
}
