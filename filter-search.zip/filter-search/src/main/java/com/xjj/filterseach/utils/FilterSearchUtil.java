package com.xjj.filterseach.utils;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.xjj.common.PageData;
import com.xjj.filterseach.annotation.FilterQueryField;
import com.xjj.filterseach.dto.FilterDTO;
import com.xjj.filterseach.dto.FilterField;
import com.xjj.filterseach.dto.SearchDTO;
import com.xjj.filterseach.dto.WhereAndLimit;
import com.xjj.filterseach.enums.OperatorType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

/**
 * 过滤器查询工具类
 *
 * @author xjj
 */
@Slf4j
@Component
public class FilterSearchUtil {
    @Resource
    JdbcTemplate jdbcTemplate;

    private final static String DEFAULT_LIMIT = " limit 10 ";

    /**
     * 获取过滤字段
     *
     * @param clz 实体类
     */
    public static List<FilterField> getFieldList(Class<?> clz) {
        ArrayList<FilterField> fields = new ArrayList<>();
        Field[] list = clz.getDeclaredFields();
        for (Field field : list) {
            if (field.isAnnotationPresent(FilterQueryField.class)) {
                FilterQueryField annotation = field.getAnnotation(FilterQueryField.class);
                fields.add(new FilterField(annotation.fieldName(), annotation.label(), annotation.type()));
            }
        }
        return fields;
    }

    /**
     * 获取分页数据
     *
     * @param entityClz 实体类
     * @param searchDTO 查询DTO
     * @param resultClz 返回类型
     */
    public <T> PageData<T> getPageData(Class<?> entityClz, SearchDTO searchDTO, Class<T> resultClz) {
        String tableName = entityClz.getAnnotation(TableName.class).value();
        if (StringUtils.isBlank(tableName)) {
            throw new IllegalArgumentException("tableName is null");
        }
        Integer total = getCount(tableName, searchDTO);
        List<T> listByPage = getListByPage(tableName, searchDTO, resultClz);
        return new PageData<>(listByPage, total);
    }

    private Integer getCount(String tableName, SearchDTO searchDTO) {
        StringBuilder sqlBuild = new StringBuilder();
        sqlBuild.append("select count( ").append(tableName).append(".id ) from ").append(tableName);
        List<FilterDTO> list = searchDTO.getList();
        sqlBuild.append(getWhereSQL(list));
        Integer total = jdbcTemplate.queryForObject(sqlBuild.toString(), Integer.class);
        return total != null ? total : 0;
    }

    /**
     * 过滤器查询分页集合
     *
     * @param tableName 表名
     * @param searchDTO 查询DTO
     * @param resultClz 返回类型
     */
    private <T> List<T> getListByPage(String tableName, SearchDTO searchDTO, Class<T> resultClz) {
        if (StringUtils.isBlank(tableName)) {
            throw new IllegalArgumentException("tableName is null");
        }
        StringBuilder sqlBuild = new StringBuilder();
        List<FilterDTO> list = searchDTO.getList();
        sqlBuild.append("select * from ").append(tableName);
        sqlBuild.append(getWhereSQL(list));
        sqlBuild.append(getLimit(searchDTO));
        List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sqlBuild.toString());
        return handleResultSets(resultList, resultClz);
    }

    /**
     * 根据查询DTO 拼接 where 条件
     *
     * @param list     查询字段集合
     */
    private String getWhereSQL(List<FilterDTO> list) {
        if (list.isEmpty()){
            return "";
        }
        StringBuilder sqlBuild = new StringBuilder();
        int i = 0;
        for (FilterDTO filter : list) {
            OperatorType type = filter.getOperatorType();
            Method targetMethod = OperatorType.getMethodByOperatorType(type);
            if (targetMethod == null){
                continue;
            }
            if (i++ == 0) {
                sqlBuild.append(" where ");
            }else {
                sqlBuild.append(" and ");
            }
            try {
                targetMethod.invoke(type, filter, sqlBuild);
            } catch (IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
                throw new RuntimeException();
            }
        }
        return sqlBuild.toString();
    }

    private String getLimit(SearchDTO searchDTO){
        if (searchDTO.getParams() == null){
            return DEFAULT_LIMIT;
        }
        //当前页
        Integer page = (Integer) searchDTO.getParams().get("page");
        // n 条/页
        Integer limit = (Integer) searchDTO.getParams().get("limit");
        StringBuilder sql = new StringBuilder();
        if (limit != null && page != null) {
            sql.append(" limit ")
                    .append((page - 1) * limit)
                    .append(",")
                    .append(limit);
            return sql.toString();
        }
        return DEFAULT_LIMIT;
    }

    /**
     * 获取 whereSQL 和 limitSQL
     * @param searchDTO
     * @return
     */
    public WhereAndLimit getWhereAndLimit(SearchDTO searchDTO){
        WhereAndLimit whereAndLimit = new WhereAndLimit();
        whereAndLimit.setLimitSql(getLimit(searchDTO));
        whereAndLimit.setWhereSql(getWhereSQL(searchDTO.getList()));
        return whereAndLimit;
    }

    /**
     * 处理结果集
     *
     * @param resultSets 结果集
     * @param clz        返回结果类型
     */
    private <T> List<T> handleResultSets(List<Map<String, Object>> resultSets, Class<T> clz) {
        if (resultSets == null || resultSets.isEmpty() || clz == null) {
            return new ArrayList<>();
        }
        Field[] fields = clz.getDeclaredFields();
        Map<String, Field> fieldMap = new HashMap<>(fields.length);
        for (Field field : fields) {
            fieldMap.putIfAbsent(field.getName(), field);
        }
        Map<String, Field> columnToFieldMap = new HashMap<>(fields.length);
        for (String column : resultSets.get(0).keySet()) {
            Field field = fieldMap.get(StrUtil.toCamelCase(column));
            if (field != null) {
                columnToFieldMap.put(column, field);
            }
        }

        List<T> beanList = new ArrayList<>();
        for (Map<String, Object> resultSet : resultSets) {
            try {
                T bean = clz.newInstance();
                for (String column : resultSet.keySet()) {
                    Field field = columnToFieldMap.get(column);
                    if (field == null) {
                        continue;
                    }
                    field.setAccessible(true);
                    Object dbValue = resultSet.get(column);
                    // 非日期时间类型的字段，直接设置值
                    if (!Objects.equals(field.getType(),Date.class)) {
                        field.set(bean, dbValue);
                        continue;
                    }

                    // 如果字段的类型是java.util.Date
                    if (dbValue instanceof Timestamp) {
                        // 直接将java.sql.Timestamp转换为java.util.Date
                        Timestamp timestamp = (Timestamp) dbValue;
                        Date date = new Date(timestamp.getTime());
                        field.set(bean, date);
                    } else if (dbValue instanceof LocalDateTime) {
                        Date date = Date.from(((LocalDateTime) dbValue).atZone(ZoneId.systemDefault()).toInstant());
                        field.set(bean, date);
                    } else if (dbValue instanceof Date) {
                        field.set(bean, dbValue);
                    } else if (dbValue != null) {
                        // 如果数据库返回的是其他格式的数据，可以考虑进行日期时间字符串解析
                        try {
                            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            Date date = dateFormat.parse(dbValue.toString());
                            field.set(bean, date);
                        } catch (ParseException e) {
                            e.printStackTrace();
                            throw new RuntimeException("日期时间解析异常");
                        }
                    }
                }
                beanList.add(bean);
            } catch (InstantiationException | IllegalAccessException e) {
                e.printStackTrace();
                throw new RuntimeException("结果集映射异常");
            }
        }
        return beanList;
    }
}
