package com.xjj.filterseach.dto;

import com.xjj.filterseach.enums.FieldType;
import com.xjj.filterseach.enums.OperatorType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 字段基类
 *
 * @author xjj
 */
@Getter
@Setter
@ToString
public class FilterField implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 字段名称
     */
    private String fieldName;
    /**
     * 字段标签
     */
    private String label;
    /**
     * 字段类型
     */
    private FieldType type;
    /**
     * 操作类型列表
     */
    private final List<Operator> operators = new ArrayList<>();

    public FilterField(String fieldName, String label, FieldType type) {
        this.fieldName = fieldName;
        this.label = label;
        this.type = type;
        //根据字段类型构建操作类型列表
        for (OperatorType operatorType : type.getOperatorType()) {
            operators.add(new Operator(operatorType, operatorType.getValue(), operatorType.getLabel()));
        }
    }
}
