package com.xjj.filterseach.dto;


import com.sun.istack.internal.NotNull;
import com.xjj.filterseach.enums.FieldType;
import com.xjj.filterseach.enums.OperatorType;
import lombok.Data;

import java.io.Serializable;

/**
 * 过滤字段DTO
 * @author xjj
 */
@Data
public class FilterDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 字段名称
     */
    @NotNull
    private String fieldName;
    /**
     * 字段类型
     */
    @NotNull
    private FieldType fieldType;
    /**
     * 操作类型
     */
    @NotNull
    private OperatorType operatorType;
    /**
     * 值
     */
    @NotNull
    private Object[] value;
}
