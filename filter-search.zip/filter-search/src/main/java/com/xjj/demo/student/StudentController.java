package com.xjj.demo.student;

import com.xjj.common.PageData;
import com.xjj.filterseach.dto.FilterField;
import com.xjj.filterseach.dto.SearchDTO;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("student")
public class StudentController {
    private final StudentService studentService;

    @GetMapping("/{id}")
    public StudentEntity get(@PathVariable("id") Integer id) {
        return studentService.getById(id);
    }

    @GetMapping("filter")
    public List<FilterField> filter() {
        return studentService.getFilterField();
    }

    @GetMapping("filter-search")
    public PageData<StudentDTO> filterSearch(@RequestBody SearchDTO searchDTO) {
        return studentService.filterSearchSingleton(searchDTO);
    }
}
