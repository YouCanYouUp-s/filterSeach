package com.xjj.demo.student;

import cn.hutool.core.lang.Opt;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xjj.common.PageData;
import com.xjj.demo.school.SchoolService;
import com.xjj.filterseach.dto.FilterField;
import com.xjj.filterseach.dto.SearchDTO;
import com.xjj.filterseach.utils.FilterSearchUtil;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author xjj
 */
@Service
public class StudentServiceImpl extends ServiceImpl<StudentDao, StudentEntity> implements StudentService {
    @Autowired
    private FilterSearchUtil filterSearchUtil;
    @Autowired
    private SchoolService schoolService;

    /**
     * 过滤器字段
     */
    private final static List<FilterField> FIELDS = FilterSearchUtil.getFieldList(StudentEntity.class);

    private void correlation(StudentDTO dto){
        Opt.ofNullable(schoolService.getById(dto.getSchoolId())).ifPresent(s -> dto.setSchoolName(s.getName()));
    }

    @Override
    public PageData<StudentDTO> filterSearchSingleton(SearchDTO searchDTO) {
        PageData<StudentDTO> pageData = filterSearchUtil.getPageData(getEntityClass(), searchDTO, StudentDTO.class);
        pageData.getList().stream().peek( this::correlation).collect(Collectors.toList());
        return pageData;
    }

    public PageData<StudentDTO> filterSearchJointTable(SearchDTO searchDTO) {
        List<StudentDTO> list = baseMapper.getSearchList(filterSearchUtil.getWhereAndLimit(searchDTO));
        return new PageData<>(list, list.size());
    }

    public List<FilterField> getFilterField() {
        return FIELDS;
    }
}
