package com.xjj.demo.school;

import lombok.Data;

import java.io.Serializable;

/**
 * @author xjj
 */
@Data
public class SchoolDTO implements Serializable {

}
