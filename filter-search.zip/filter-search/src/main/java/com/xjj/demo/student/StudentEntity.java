package com.xjj.demo.student;

import com.baomidou.mybatisplus.annotation.TableName;
import com.xjj.filterseach.annotation.FilterQueryField;
import com.xjj.filterseach.enums.FieldType;
import lombok.Data;

/**
 * @author xjj
 */
@Data
@TableName("student")
public class StudentEntity {
    private Integer id;
    @FilterQueryField(fieldName = "name", label = "学生名称", type = FieldType.STRING_FIELD)
    private String name;
    private Integer schoolId;
}
