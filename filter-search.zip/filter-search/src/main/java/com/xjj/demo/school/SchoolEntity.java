package com.xjj.demo.school;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * @author xjj
 */
@Data
@TableName("school")
public class SchoolEntity {
    private Integer id;
    private String name;
}
