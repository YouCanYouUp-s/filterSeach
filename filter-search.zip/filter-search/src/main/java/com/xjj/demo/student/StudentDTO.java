package com.xjj.demo.student;

import lombok.Data;

import java.io.Serializable;

/**
 * @author xjj
 */
@Data
public class StudentDTO implements Serializable {
    private Long id;
    private String name;
    private Long schoolId;
    private String schoolName;
}
