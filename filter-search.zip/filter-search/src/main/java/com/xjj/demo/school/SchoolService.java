package com.xjj.demo.school;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @author xjj
 */
public interface SchoolService extends IService<SchoolEntity> {
}
