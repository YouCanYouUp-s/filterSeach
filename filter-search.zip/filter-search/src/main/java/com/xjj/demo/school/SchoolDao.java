package com.xjj.demo.school;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author xjj
 */
@Mapper
public interface SchoolDao extends BaseMapper<SchoolEntity> {
}
