package com.xjj.demo.student;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xjj.common.PageData;
import com.xjj.filterseach.dto.FilterField;
import com.xjj.filterseach.dto.SearchDTO;

import java.util.List;


/**
 * @author xjj
 */
public interface StudentService extends IService<StudentEntity> {
    List<FilterField> getFilterField();
    /**
     * 使用过滤器查询
     * @param searchDTO
     * @return
     */
    PageData<StudentDTO> filterSearchSingleton(SearchDTO searchDTO);
}
