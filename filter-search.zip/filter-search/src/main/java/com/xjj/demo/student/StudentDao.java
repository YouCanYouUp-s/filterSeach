package com.xjj.demo.student;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xjj.filterseach.dto.WhereAndLimit;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author xjj
 */
@Mapper
public interface StudentDao extends BaseMapper<StudentEntity> {
    /**
     * 过滤器-联表查询
     * @param whereAndLimit
     * @return
     */
    List<StudentDTO> getSearchList(WhereAndLimit whereAndLimit);
}
